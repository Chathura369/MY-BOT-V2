# WhatsApp NSFW Super Bot 🤖

A powerful WhatsApp bot for downloading videos from multiple adult content sites with quality options, search functionality, and a web-based dashboard.

## ✨ Features

- 📥 **Multi-Site Downloads**: Pornhub, XVideos, XNXX, xHamster, YouPorn, SpankBang, RedTube
- ⚙️ **Quality Options**: HD (1080p), SD (720p), Low (480p)
- 🔍 **Multi-Site Search**: Search across all supported platforms
- 🌐 **Web Dashboard**: Real-time monitoring with QR code display
- ⚡ **Low RAM Mode**: Optimized to run with only 256MB memory
- 🏓 **Ping Command**: Check bot response time

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ installed
- WhatsApp account

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/whatsapp-bot.git
cd whatsapp-bot
```

2. **Install dependencies**
```bash
npm install
```

3. **Run the bot**
```bash
npm start
```

4. **Connect WhatsApp**
- Open http://localhost:3000 in your browser
- Scan the QR code with WhatsApp (Linked Devices)
- Wait for "Connected" status

## 📱 Commands

### Download Commands
```
.ph <link>     - Download from Pornhub
.xv <link>     - Download from XVideos
.xnxx <link>   - Download from XNXX
.xh <link>     - Download from xHamster
.yp <link>     - Download from YouPorn
.sb <link>     - Download from SpankBang
.rt <link>     - Download from RedTube
```

### Quality Options
```
.ph hd <link>  - High Quality (1080p)
.ph sd <link>  - Standard Quality (720p)
.ph low <link> - Ultra Data Saver (480p)
```

### Search
```
.search <keyword>  - Search all sites
.s <keyword>       - Short search command
```

### Utility
```
.ping    - Check bot response time
.menu    - Show all commands
.help    - Show all commands
```

## 🔧 Configuration

Edit `config.js` to customize:

```javascript
module.exports = {
    PORT: 3000,                        // Dashboard port
    DASHBOARD_PASS: 'chathura123',     // Dashboard password
    SESSION_DIR: './session',          // WhatsApp session directory
    DOWNLOAD_DIR: './downloads',       // Download directory
    BROWSER: ['SuperBot', 'Chrome', '131.0']
};
```

## 🌐 GitHub Workflow

This project includes a GitHub Actions workflow for automated deployment.

### Manual Trigger
1. Go to your repository on GitHub
2. Click "Actions" tab
3. Select "Run WhatsApp Bot" workflow
4. Click "Run workflow"

### Automatic Trigger
The workflow runs automatically on:
- Push to `main` or `master` branch
- Pull requests to `main` or `master` branch

## 📂 Project Structure

```
├── bot.js           # WhatsApp bot logic
├── commands.js      # Command processing
├── config.js        # Configuration
├── dashboard.js     # Web dashboard
├── downloader.js    # Video download & compression
├── index.js         # Entry point
├── logger.js        # Logging system
├── search.js        # Multi-site search
└── .github/
    └── workflows/
        └── run-bot.yml  # GitHub Actions workflow
```

## 🛠️ Tech Stack

- **@whiskeysockets/baileys** - WhatsApp Web API
- **Express** & **Socket.io** - Web dashboard
- **yt-dlp** - Video downloading
- **FFmpeg** - Video compression
- **Cheerio** & **Axios** - Web scraping

## 📊 Dashboard

Access the dashboard at http://localhost:3000

Features:
- Real-time connection status
- QR code display
- Live server logs
- Bot controls

## ⚠️ Important Notes

- Keep your `session/` folder secure (contains WhatsApp credentials)
- The bot uses low RAM mode (256MB limit)
- Large videos are automatically split into parts
- Videos are compressed to save bandwidth

## 📝 License

This project is for educational purposes only.

## 🤝 Contributing

Pull requests are welcome! For major changes, please open an issue first.
